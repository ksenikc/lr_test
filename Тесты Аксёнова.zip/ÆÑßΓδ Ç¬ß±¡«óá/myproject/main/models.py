from django.db import models


class Product(models.Model):
    number = models.IntegerField('Номер', max_length=50)
    name = models.CharField('Наименование', max_length=50)
    price = models.IntegerField('Цена', max_length=50)
    quantity = models.CharField('Количество', max_length=50)
    manufacturer = models.CharField('Производитель', max_length=50)
    photo = models.ImageField(upload_to="photos", default=None, blank=True, null=True, verbose_name="Фото")
    objects = models.Manager()

    @property
    def photo_url(self):
        if self.photo and hasattr(self.photo, 'url'):
            return self.photo.url

    def __int__(self):
        return self.number

    class Meta:
        verbose_name = 'Товар'
        verbose_name_plural = 'Товары'
