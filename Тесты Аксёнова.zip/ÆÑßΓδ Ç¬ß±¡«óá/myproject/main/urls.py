from django.contrib import admin
from django.urls import path
from . import views

from myproject import settings
from django.conf.urls.static import static

urlpatterns = [
                  path('', views.index, name='home'),
                  path('delivery', views.delivery),
                  path('add', views.add),
                  path('care', views.care),
                  path('<int:pk>/delete', views.ProductDeleteView.as_view(), name='task-delete'),
                  path('<int:pk>/update', views.ProductUpdateView.as_view(), name='task-update'),
              ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
