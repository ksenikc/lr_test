from .models import Product
from django.forms import ModelForm, TextInput, FileField, ClearableFileInput
from django.forms import FileInput


class ProductForm(ModelForm):
    class Meta:
        model = Product
        fields = ["number", "name", "price", "quantity", "manufacturer", "photo"]
        widgets = {
            "number": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Введите номер'
            }),
            "name": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Введите наименование'
            }),
            "price": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Введите цену'
            }),

            "quantity": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Введите количество'
            }),
            "manufacturer": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Введите производителя'
            }),
            "photo": FileInput(attrs={
                'class': 'p_files',
                'placeholder': 'Файлы'
            }),
        }
