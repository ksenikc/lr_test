from unittest import skip
from django.test import LiveServerTestCase
from selenium import webdriver
from main.models import Product
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By


class NameFunctionalTest(LiveServerTestCase):
    def setUp(self):
        self.selenium = webdriver.Chrome()
        super().setUp()

    def tearDown(self):
        self.selenium.quit()
        super().tearDown()

    def test_product_list_functional(self):
        # Create test data
        Product.objects.create(name='Диван')
        Product.objects.create(name='Стол')

        # Simulate user interactions using Selenium
        self.selenium.get(self.live_server_url + '/product/')
        self.assertIn('Список Товаров', self.selenium.name)
        names = self.selenium.find_elements(By.TAG_NAME, 'td')
        self.assertEqual(len(names), 2)
        self.assertEqual(names[0].text, 'Диван')
        self.assertEqual(names[1].text, 'Стол')