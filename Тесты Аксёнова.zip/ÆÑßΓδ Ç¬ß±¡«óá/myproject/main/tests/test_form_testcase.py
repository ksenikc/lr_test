from unittest import skip
from django.test import TestCase
from main.forms import ProductForm


class FormTest(TestCase):
    def test_form_valid(self):
        form_data = {'name': 'Диван',
                     "number": '1',
                     "price": '1000',
                     "quantity": '1',
                     "manufacturer": 'Россия'}
        form = ProductForm(data=form_data)
        self.assertTrue(form.is_valid())

    def test_form_invalid(self):
        form_data = {'name': '',
                     "number": '',
                     "price": '',
                     "quantity": '',
                     "manufacturer": ''}
        form = ProductForm(data=form_data)
        self.assertFalse(form.is_valid())
