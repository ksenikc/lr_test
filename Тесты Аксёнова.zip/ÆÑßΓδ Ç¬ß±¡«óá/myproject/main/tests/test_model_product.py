from django.test import TestCase
from main.models import Product


class ProductModelTest(TestCase):

    @classmethod
    def setUpTestData(cls):
        Product.objects.create(name='Стол',number='1', price='1000', quantity="2")

    def test_first_name_label(self):
        product = Product.objects.get(id=1)
        field_label = product._meta.get_field('name').verbose_name
        self.assertEqual(field_label, 'Наименование')

    def test_phone_label(self):
        product = Product.objects.get(id=1)
        field_label = product._meta.get_field('number').verbose_name
        self.assertEqual(field_label, 'Номер')

    def test_surname_max_length(self):
        product = Product.objects.get(id=1)
        max_length = product._meta.get_field('price').max_length
        self.assertEqual(max_length, 50)

    def test_get_absolute_url(self):
        product = Product.objects.get(id=1)
        self.assertEqual(product.get_absolute_url(), 'product/1')
