from unittest import skip
from django.test import TestCase, RequestFactory
from unittest.mock import Mock, patch
from main.models import Product
from main.views import index


class ProductListViewTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()

    def test_name_list_view(self):
        Product.objects.create(name='Стол')
        Product.objects.create(name='Стул')

        request = self.factory.get('/index/')

        mock_queryset = Mock(spec=Product.objects.all())
        mock_queryset.return_value = [
            Mock(name='Стол'),
            Mock(name='Стул')
        ]

        with patch('main.views.Product.objects.all', mock_queryset):
            response = index(request)

        self.assertEqual(response.status_code, 200)

        self.assertContains(response, 'Стол')
        self.assertContains(response, 'Стул')