from unittest import skip
from django.test import TestCase
from main.models import Product


class MyModelTest(TestCase):
    def setUp(self):
        self.object = Product.objects.create(number="5")

    def test_str_representation(self):
        self.assertEqual(str(self.object), '5')

    def tearDown(self):
        pass
